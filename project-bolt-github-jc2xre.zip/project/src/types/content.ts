export interface ContentMetadata {
  title: string;
  type: 'youtube' | 'pdf' | 'text';
  source: string;
  length?: number;
  timestamp: string;
}

export interface AnalysisResult {
  summary: string;
  topics: string[];
  difficulty: 'beginner' | 'intermediate' | 'advanced';
  estimatedDuration: number;
  suggestedKIUPoints: number;
  confidence: number;
}

export interface ContentAnalysis {
  metadata: ContentMetadata;
  analysis: AnalysisResult;
  rawContent: string;
}