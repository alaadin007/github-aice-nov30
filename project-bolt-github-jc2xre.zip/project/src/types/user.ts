export interface UserDetails {
  fullName: string;
  email: string;
  organization: string;
  certificateId?: string;
}