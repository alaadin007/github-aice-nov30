import { z } from 'zod';

export const DifficultyLevel = z.enum(['beginner', 'intermediate', 'advanced']);
export type DifficultyLevel = z.infer<typeof DifficultyLevel>;

export const AssessmentQuestion = z.object({
  id: z.string(),
  text: z.string(),
  options: z.array(z.object({
    id: z.string(),
    text: z.string()
  })),
  correctAnswer: z.string(),
  difficulty: DifficultyLevel,
  explanation: z.string().optional()
});
export type AssessmentQuestion = z.infer<typeof AssessmentQuestion>;

export const KIUCalculation = z.object({
  baseKnowledge: z.number(),
  difficultyMultiplier: z.number(),
  learnerEfficiencyFactor: z.number(),
  baselineAdjustment: z.number(),
  totalKIU: z.number()
});
export type KIUCalculation = z.infer<typeof KIUCalculation>;

export const KnowledgeFusionScore = z.object({
  totalKIUs: z.number(),
  diversityFactor: z.number(),
  progressionRate: z.number(),
  assessmentProficiency: z.number(),
  finalScore: z.number(),
  proficiencyLevel: z.enum(['Certificate', 'Diploma', 'Bachelor', 'Master', 'PhD'])
});
export type KnowledgeFusionScore = z.infer<typeof KnowledgeFusionScore>;

export const ContentCredits = z.object({
  kiu: z.number(),
  cpd: z.number(),
  cme: z.number(),
  ce: z.number()
});
export type ContentCredits = z.infer<typeof ContentCredits>;