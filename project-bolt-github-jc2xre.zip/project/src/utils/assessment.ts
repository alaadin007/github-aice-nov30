import OpenAI from 'openai';
import { config } from '../config';
import type { AssessmentQuestion, DifficultyLevel } from '../types/kiu';

const openai = new OpenAI({
  apiKey: config.openaiApiKey,
  organization: config.openaiOrgId,
  dangerouslyAllowBrowser: true // Enable browser usage
});

const ASSESSMENT_PROMPT = `Generate multiple choice questions based on the provided content.
Each question should:
1. Test understanding of key concepts
2. Have 4 options (a, b, c, d)
3. Include one correct answer
4. Be assigned a difficulty level
5. Include a brief explanation for the correct answer

Format the output as a JSON array of questions.`;

export async function generateQuestions(
  content: string,
  count: number = 10
): Promise<AssessmentQuestion[]> {
  try {
    const completion = await openai.chat.completions.create({
      model: "gpt-4-turbo-preview",
      messages: [
        { role: "system", content: ASSESSMENT_PROMPT },
        { 
          role: "user", 
          content: `Generate ${count} questions for this content:\n\n${content}`
        }
      ],
      temperature: 0.7,
      max_tokens: 2000,
      response_format: { type: "json_object" }
    });

    const result = JSON.parse(completion.choices[0].message.content || '{}');
    return result.questions.map((q: any, index: number) => ({
      id: `q${index + 1}`,
      text: q.question,
      options: q.options.map((opt: any, i: number) => ({
        id: String.fromCharCode(97 + i), // a, b, c, d
        text: opt
      })),
      correctAnswer: q.correct_answer.toLowerCase(),
      difficulty: q.difficulty.toLowerCase(),
      explanation: q.explanation
    }));
  } catch (error) {
    console.error('Error generating questions:', error);
    throw new Error('Failed to generate assessment questions');
  }
}

export function calculateAssessmentScore(
  questions: AssessmentQuestion[],
  answers: Record<string, string>
): number {
  const totalQuestions = questions.length;
  if (totalQuestions === 0) return 0;

  const correctAnswers = questions.reduce((count, question) => {
    const userAnswer = answers[question.id];
    return userAnswer === question.correctAnswer ? count + 1 : count;
  }, 0);

  return (correctAnswers / totalQuestions) * 100;
}