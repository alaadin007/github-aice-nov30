import axios from 'axios';
import { config } from '../config';

interface YouTubeSearchParams {
  q: string;
  gl?: string;
  hl?: string;
  sp?: string;
}

interface YouTubeVideo {
  title: string;
  url: string;
  duration: string;
  views: string;
  thumbnail: string;
  description: string;
}

export async function searchYouTube(params: YouTubeSearchParams): Promise<YouTubeVideo[]> {
  try {
    const response = await axios.get(config.youtubeApiEndpoint, {
      params: {
        ...params,
        engine: 'youtube',
        api_key: config.searchApiKey
      }
    });

    return response.data.video_results.map((video: any) => ({
      title: video.title,
      url: video.link,
      duration: video.duration,
      views: video.views,
      thumbnail: video.thumbnail.static,
      description: video.description
    }));
  } catch (error) {
    console.error('Error searching YouTube:', error);
    throw new Error('Failed to search YouTube videos');
  }
}

export async function extractSubtitles(videoUrl: string): Promise<string> {
  try {
    // Extract video ID from URL
    const videoId = videoUrl.match(/(?:youtu\.be\/|youtube\.com(?:\/embed\/|\/v\/|\/watch\?v=|\/user\/\S+|\/ytscreeningroom\?v=|\/sandalsResorts#\w\/\w\/.*\/))([^\/&\?]{10,12})/)?.[1];
    
    if (!videoId) {
      throw new Error('Invalid YouTube URL');
    }

    // Fetch captions from our backend
    const response = await axios.get(`${config.apiUrl}/api/youtube/captions/${videoId}`);
    return response.data.captions;
  } catch (error) {
    console.error('Error extracting subtitles:', error);
    throw new Error('Failed to extract video subtitles');
  }
}

export function validateYouTubeUrl(url: string): boolean {
  const pattern = /^(https?:\/\/)?(www\.)?(youtube\.com|youtu\.?be)\/.+$/;
  return pattern.test(url);
}