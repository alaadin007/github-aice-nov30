import type { KIUCalculation, ContentCredits, DifficultyLevel } from '../types/kiu';

const DIFFICULTY_WEIGHTS: Record<DifficultyLevel, number> = {
  beginner: 0.6,
  intermediate: 0.8,
  advanced: 1.0
};

const LEARNER_EFFICIENCY_FACTORS = {
  general: 0.8,
  professional: 1.0,
  specialist: 1.2
};

export function calculateKIU(
  contentLength: number,
  difficulty: DifficultyLevel,
  learnerType: keyof typeof LEARNER_EFFICIENCY_FACTORS = 'professional'
): KIUCalculation {
  const baseKnowledge = 1;
  const difficultyMultiplier = DIFFICULTY_WEIGHTS[difficulty];
  const learnerEfficiencyFactor = LEARNER_EFFICIENCY_FACTORS[learnerType];
  const baselineAdjustment = Math.log10(contentLength / 100 + 1) + 1;

  const totalKIU = Math.round(
    baseKnowledge * 
    difficultyMultiplier * 
    learnerEfficiencyFactor * 
    baselineAdjustment * 
    10
  ) / 10;

  return {
    baseKnowledge,
    difficultyMultiplier,
    learnerEfficiencyFactor,
    baselineAdjustment,
    totalKIU
  };
}

export function convertToCredits(kiu: number): ContentCredits {
  // Standard conversion rates
  const KIU_TO_HOUR = 1; // 1 KIU = 1 hour of learning
  
  const hours = kiu * KIU_TO_HOUR;
  
  return {
    kiu,
    cpd: Math.round(hours * 10) / 10, // CPD credits = hours
    cme: Math.round(hours * 10) / 10, // CME credits = hours
    ce: Math.round(hours * 10) / 10   // CE credits = hours
  };
}

export function estimateStudyTime(
  wordCount: number,
  difficulty: DifficultyLevel
): number {
  // Average reading speed (words per minute)
  const BASE_READING_SPEED = 200;
  
  // Difficulty adjustments
  const DIFFICULTY_TIME_MULTIPLIERS: Record<DifficultyLevel, number> = {
    beginner: 1.2,    // 20% more time for comprehension
    intermediate: 1.5, // 50% more time for comprehension
    advanced: 2.0     // Double time for comprehension
  };

  const baseMinutes = wordCount / BASE_READING_SPEED;
  const adjustedMinutes = baseMinutes * DIFFICULTY_TIME_MULTIPLIERS[difficulty];
  
  // Round to nearest 5 minutes
  return Math.ceil(adjustedMinutes / 5) * 5;
}