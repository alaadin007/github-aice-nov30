import React, { useState } from 'react';
import { YouTubeInput } from './YouTubeInput';
import { ContentAnalyzer } from './ContentAnalyzer';
import { AssessmentGenerator } from './AssessmentGenerator';
import { PersonalDetails } from './PersonalDetails';
import type { ContentMetadata } from '../types/content';

type FlowStep = 'input' | 'analysis' | 'assessment' | 'details';

export function YouTubeFlow() {
  const [currentStep, setCurrentStep] = useState<FlowStep>('input');
  const [content, setContent] = useState<string>('');
  const [metadata, setMetadata] = useState<ContentMetadata | null>(null);
  const [analysisResult, setAnalysisResult] = useState(null);
  const [error, setError] = useState<string | null>(null);

  const handleSubtitlesExtracted = (subtitles: string) => {
    setContent(subtitles);
    setMetadata({
      title: 'YouTube Video', // This would come from video metadata
      type: 'youtube',
      source: 'youtube',
      timestamp: new Date().toISOString()
    });
    setCurrentStep('analysis');
  };

  const handleAnalysisComplete = (result: any) => {
    setAnalysisResult(result);
    setCurrentStep('assessment');
  };

  const handleAssessmentComplete = (score: number) => {
    if (score >= 70) { // Pass threshold
      setCurrentStep('details');
    } else {
      setError('Assessment score too low. Please review the content and try again.');
    }
  };

  const renderCurrentStep = () => {
    switch (currentStep) {
      case 'input':
        return (
          <YouTubeInput
            onSubtitlesExtracted={handleSubtitlesExtracted}
            onError={setError}
          />
        );

      case 'analysis':
        return metadata && (
          <ContentAnalyzer
            content={content}
            metadata={metadata}
            onAnalysisComplete={handleAnalysisComplete}
          />
        );

      case 'assessment':
        return (
          <AssessmentGenerator
            content={content}
            onComplete={handleAssessmentComplete}
          />
        );

      case 'details':
        return (
          <PersonalDetails
            onComplete={() => {
              // Handle certificate generation
              console.log('Certificate generated!');
            }}
            onBack={() => setCurrentStep('assessment')}
          />
        );

      default:
        return null;
    }
  };

  return (
    <div className="max-w-4xl mx-auto px-6">
      {/* Progress Steps */}
      <div className="mb-8">
        <div className="flex justify-between">
          {[
            { id: 'input', label: 'Content' },
            { id: 'analysis', label: 'Analysis' },
            { id: 'assessment', label: 'Assessment' },
            { id: 'details', label: 'Certificate' }
          ].map((step, index) => (
            <div
              key={step.id}
              className="flex items-center"
            >
              <div className={`flex items-center justify-center w-8 h-8 rounded-full ${
                currentStep === step.id
                  ? 'bg-blue-500 text-white'
                  : 'bg-zinc-800 text-gray-400'
              }`}>
                {index + 1}
              </div>
              <span className={`ml-2 text-sm ${
                currentStep === step.id ? 'text-white' : 'text-gray-400'
              }`}>
                {step.label}
              </span>
              {index < 3 && (
                <div className="w-full h-[2px] mx-4 bg-zinc-800">
                  <div className={`h-full bg-blue-500 transition-all ${
                    ['input', 'analysis', 'assessment', 'details']
                      .indexOf(currentStep) > index ? 'w-full' : 'w-0'
                  }`} />
                </div>
              )}
            </div>
          ))}
        </div>
      </div>

      {/* Error Display */}
      {error && (
        <div className="mb-6 p-4 bg-red-500/10 text-red-400 rounded-xl">
          {error}
        </div>
      )}

      {/* Current Step Content */}
      {renderCurrentStep()}
    </div>
  );
}