import React from 'react';
import { X } from 'lucide-react';
import { YouTubeFlow } from './YouTubeFlow';

interface YouTubeModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export function YouTubeModal({ isOpen, onClose }: YouTubeModalProps) {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50 p-4">
      <div className="bg-zinc-900 rounded-2xl w-full max-w-4xl relative animate-fadeIn border border-zinc-800">
        <button
          onClick={onClose}
          className="absolute -right-3 -top-3 w-8 h-8 bg-zinc-800 hover:bg-zinc-700 rounded-full flex items-center justify-center text-gray-400 hover:text-white transition-all duration-200 border border-zinc-700 shadow-lg"
        >
          <X className="w-4 h-4" />
        </button>

        <div className="p-8">
          <YouTubeFlow />
        </div>
      </div>
    </div>
  );
}