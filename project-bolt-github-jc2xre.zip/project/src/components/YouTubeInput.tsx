import React, { useState } from 'react';
import { Search, AlertCircle } from 'lucide-react';
import { validateYouTubeUrl, extractVideoId, extractSubtitles } from '../services/youtube';

interface YouTubeInputProps {
  onSubtitlesExtracted: (subtitles: string, videoInfo?: any) => void;
  onError: (error: string) => void;
}

export function YouTubeInput({ onSubtitlesExtracted, onError }: YouTubeInputProps) {
  const [url, setUrl] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validateYouTubeUrl(url)) {
      setError('Please enter a valid YouTube URL');
      return;
    }

    const videoId = extractVideoId(url);
    if (!videoId) {
      setError('Could not extract video ID from URL');
      return;
    }

    setIsLoading(true);
    setError(null);

    try {
      const { captions, videoInfo } = await extractSubtitles(videoId);
      onSubtitlesExtracted(captions, videoInfo);
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Failed to extract subtitles';
      setError(message);
      onError(message);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="w-full">
      <form onSubmit={handleSubmit} className="space-y-4">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
          <input
            type="url"
            value={url}
            onChange={(e) => setUrl(e.target.value)}
            placeholder="Paste YouTube video URL..."
            className="w-full pl-10 pr-4 py-3 bg-zinc-800 border border-zinc-700 rounded-xl text-white placeholder-gray-400 focus:border-blue-500 focus:outline-none"
          />
        </div>

        {error && (
          <div className="flex items-center gap-2 text-red-400 text-sm">
            <AlertCircle className="w-4 h-4" />
            {error}
          </div>
        )}

        <button
          type="submit"
          disabled={isLoading || !url.trim()}
          className={`w-full btn-primary py-3 flex items-center justify-center gap-2 ${
            (isLoading || !url.trim()) ? 'opacity-50 cursor-not-allowed' : ''
          }`}
        >
          {isLoading ? (
            <span className="inline-block w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
          ) : (
            'Extract Subtitles'
          )}
        </button>
      </form>
    </div>
  );
}