import React, { useState } from 'react';
import { User, Mail, Building, BadgeCheck, ArrowLeft } from 'lucide-react';

interface PersonalDetailsProps {
  onComplete: (details: UserDetails) => void;
  onBack: () => void;
}

interface UserDetails {
  fullName: string;
  email: string;
  organization: string;
}

export function PersonalDetails({ onComplete, onBack }: PersonalDetailsProps) {
  const [details, setDetails] = useState<UserDetails>({
    fullName: '',
    email: '',
    organization: ''
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onComplete(details);
  };

  return (
    <div className="max-w-2xl mx-auto">
      <div className="glass-effect rounded-2xl p-8">
        <div className="text-center mb-8">
          <div className="w-16 h-16 rounded-full bg-blue-500/20 flex items-center justify-center mx-auto mb-4">
            <BadgeCheck className="w-8 h-8 text-blue-500" />
          </div>
          <h2 className="text-2xl font-bold mb-2">Complete Your Certificate</h2>
          <p className="text-gray-400">
            Enter your details to generate your certificate
          </p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">
              Full Name
            </label>
            <div className="relative">
              <User className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
              <input
                required
                type="text"
                value={details.fullName}
                onChange={e => setDetails(prev => ({ ...prev, fullName: e.target.value }))}
                className="w-full pl-10 pr-4 py-3 bg-zinc-800 border border-zinc-700 rounded-xl text-white placeholder-gray-400 focus:border-blue-500 focus:outline-none"
                placeholder="John Doe"
              />
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">
              Email
            </label>
            <div className="relative">
              <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
              <input
                required
                type="email"
                value={details.email}
                onChange={e => setDetails(prev => ({ ...prev, email: e.target.value }))}
                className="w-full pl-10 pr-4 py-3 bg-zinc-800 border border-zinc-700 rounded-xl text-white placeholder-gray-400 focus:border-blue-500 focus:outline-none"
                placeholder="john@example.com"
              />
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">
              Organization
            </label>
            <div className="relative">
              <Building className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
              <input
                required
                type="text"
                value={details.organization}
                onChange={e => setDetails(prev => ({ ...prev, organization: e.target.value }))}
                className="w-full pl-10 pr-4 py-3 bg-zinc-800 border border-zinc-700 rounded-xl text-white placeholder-gray-400 focus:border-blue-500 focus:outline-none"
                placeholder="Company or Institution"
              />
            </div>
          </div>

          <div className="flex justify-between gap-4">
            <button
              type="button"
              onClick={onBack}
              className="btn-secondary flex items-center gap-2"
            >
              <ArrowLeft className="w-4 h-4" />
              Back
            </button>
            <button
              type="submit"
              className="btn-primary flex-1"
            >
              Generate Certificate
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}