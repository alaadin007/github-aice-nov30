import React, { useState, useRef } from 'react';
import { Upload, AlertCircle, FileText, Youtube, Link as LinkIcon } from 'lucide-react';
import { processContent } from '../services/content';
import type { ContentMetadata } from '../types/content';

interface ContentInputProps {
  onContentProcessed: (content: string, metadata: ContentMetadata) => void;
  onError: (error: string) => void;
}

export function ContentInput({ onContentProcessed, onError }: ContentInputProps) {
  const [url, setUrl] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [isDragging, setIsDragging] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!url.trim()) return;

    setIsProcessing(true);
    setError(null);

    try {
      const { content, metadata } = await processContent(url);
      onContentProcessed(content, metadata);
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Failed to process content';
      setError(message);
      onError(message);
    } finally {
      setIsProcessing(false);
    }
  };

  const handleDrop = async (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);

    const files = Array.from(e.dataTransfer.files);
    if (files.length === 0) return;

    const file = files[0];
    setUrl(URL.createObjectURL(file));
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    const file = files[0];
    setUrl(URL.createObjectURL(file));
  };

  return (
    <div className="w-full">
      <div 
        className={`glass-effect rounded-2xl p-6 ${
          isDragging ? 'border-2 border-dashed border-blue-500' : ''
        }`}
        onDragEnter={(e) => {
          e.preventDefault();
          setIsDragging(true);
        }}
        onDragLeave={(e) => {
          e.preventDefault();
          setIsDragging(false);
        }}
        onDragOver={(e) => e.preventDefault()}
        onDrop={handleDrop}
      >
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="relative">
            <LinkIcon className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
            <input
              type="text"
              value={url}
              onChange={(e) => setUrl(e.target.value)}
              placeholder="Paste a link or drag & drop content..."
              className="w-full pl-10 pr-4 py-3 bg-zinc-800 border border-zinc-700 rounded-xl text-white placeholder-gray-400 focus:border-blue-500 focus:outline-none"
            />
          </div>

          {error && (
            <div className="flex items-center gap-2 text-red-400 text-sm">
              <AlertCircle className="w-4 h-4" />
              {error}
            </div>
          )}

          <div className="flex justify-between items-center">
            <button
              type="button"
              onClick={() => fileInputRef.current?.click()}
              className="btn-secondary flex items-center gap-2"
            >
              <Upload className="w-4 h-4" />
              Upload File
            </button>

            <button
              type="submit"
              disabled={isProcessing || !url.trim()}
              className="btn-primary flex items-center gap-2"
            >
              {isProcessing ? (
                <span className="inline-block w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
              ) : (
                'Process Content'
              )}
            </button>
          </div>

          <input
            ref={fileInputRef}
            type="file"
            accept=".pdf,.doc,.docx,.ppt,.pptx"
            onChange={handleFileSelect}
            className="hidden"
          />
        </form>

        {/* Drag & Drop Zone */}
        <div className="mt-6 border-2 border-dashed border-zinc-700 rounded-xl p-8 text-center hover:border-blue-500 transition-colors">
          <Upload className="w-8 h-8 text-blue-500 mx-auto mb-3" />
          <p className="text-gray-400 mb-1">
            Drag and drop files or paste a link
          </p>
          <p className="text-sm text-gray-500">
            Supported: YouTube videos, PDF, Word, PowerPoint
          </p>
        </div>

        {/* File Type Icons */}
        <div className="flex justify-center gap-8 mt-6">
          <div className="text-center">
            <div className="w-10 h-10 rounded-lg bg-blue-500/20 flex items-center justify-center mb-2">
              <Youtube className="w-5 h-5 text-blue-500" />
            </div>
            <span className="text-xs text-gray-400">YouTube</span>
          </div>
          <div className="text-center">
            <div className="w-10 h-10 rounded-lg bg-purple-500/20 flex items-center justify-center mb-2">
              <FileText className="w-5 h-5 text-purple-500" />
            </div>
            <span className="text-xs text-gray-400">PDF</span>
          </div>
          <div className="text-center">
            <div className="w-10 h-10 rounded-lg bg-green-500/20 flex items-center justify-center mb-2">
              <Upload className="w-5 h-5 text-green-500" />
            </div>
            <span className="text-xs text-gray-400">Word/PPT</span>
          </div>
        </div>
      </div>
    </div>
  );
}