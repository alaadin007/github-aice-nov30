import React, { useState } from 'react';
import { ContentInput } from './ContentInput';
import { ContentAnalyzer } from './ContentAnalyzer';
import { AssessmentGenerator } from './AssessmentGenerator';
import { PersonalDetails } from './PersonalDetails';
import { Brain } from 'lucide-react';
import type { ContentMetadata } from '../types/content';

type FlowStep = 'input' | 'analysis' | 'assessment' | 'details';

export function ContentFlow() {
  const [currentStep, setCurrentStep] = useState<FlowStep>('input');
  const [content, setContent] = useState<string>('');
  const [metadata, setMetadata] = useState<ContentMetadata | null>(null);
  const [analysisResult, setAnalysisResult] = useState(null);
  const [error, setError] = useState<string | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);

  const handleContentProcessed = async (processedContent: string, contentMetadata: ContentMetadata) => {
    setContent(processedContent);
    setMetadata(contentMetadata);
    setIsProcessing(true);
    
    // Artificial delay to show loading state
    await new Promise(resolve => setTimeout(resolve, 1500));
    
    setIsProcessing(false);
    setCurrentStep('analysis');
  };

  const handleAnalysisComplete = (result: any) => {
    setAnalysisResult(result);
    setCurrentStep('assessment');
  };

  const handleAssessmentComplete = (score: number) => {
    if (score >= 70) { // Pass threshold
      setCurrentStep('details');
    } else {
      setError('Assessment score too low. Please review the content and try again.');
    }
  };

  const renderCurrentStep = () => {
    if (isProcessing) {
      return (
        <div className="glass-effect rounded-xl p-8 text-center">
          <div className="w-16 h-16 rounded-full bg-blue-500/20 flex items-center justify-center mx-auto mb-4">
            <Brain className="w-8 h-8 text-blue-500 animate-pulse" />
          </div>
          <h3 className="text-xl font-bold mb-2">Processing Content</h3>
          <p className="text-gray-400 mb-6">
            Please wait while we analyze your content...
          </p>
          <div className="w-full h-2 bg-zinc-800 rounded-full overflow-hidden">
            <div className="h-full bg-blue-500 animate-pulse rounded-full" style={{ width: '100%' }} />
          </div>
        </div>
      );
    }

    switch (currentStep) {
      case 'input':
        return (
          <ContentInput
            onContentProcessed={handleContentProcessed}
            onError={setError}
          />
        );

      case 'analysis':
        return metadata && (
          <ContentAnalyzer
            content={content}
            metadata={metadata}
            onAnalysisComplete={handleAnalysisComplete}
          />
        );

      case 'assessment':
        return (
          <AssessmentGenerator
            content={content}
            onComplete={handleAssessmentComplete}
          />
        );

      case 'details':
        return (
          <PersonalDetails
            onComplete={() => {
              // Handle certificate generation
              console.log('Certificate generated!');
            }}
            onBack={() => setCurrentStep('assessment')}
          />
        );

      default:
        return null;
    }
  };

  return (
    <div className="max-w-4xl mx-auto px-6">
      {/* Progress Steps */}
      <div className="mb-8">
        <div className="flex justify-between">
          {[
            { id: 'input', label: 'Content' },
            { id: 'analysis', label: 'Analysis' },
            { id: 'assessment', label: 'Assessment' },
            { id: 'details', label: 'Certificate' }
          ].map((step, index) => (
            <div
              key={step.id}
              className="flex items-center"
            >
              <div className={`flex items-center justify-center w-8 h-8 rounded-full ${
                currentStep === step.id
                  ? 'bg-blue-500 text-white'
                  : 'bg-zinc-800 text-gray-400'
              }`}>
                {index + 1}
              </div>
              <span className={`ml-2 text-sm ${
                currentStep === step.id ? 'text-white' : 'text-gray-400'
              }`}>
                {step.label}
              </span>
              {index < 3 && (
                <div className="w-full h-[2px] mx-4 bg-zinc-800">
                  <div className={`h-full bg-blue-500 transition-all ${
                    ['input', 'analysis', 'assessment', 'details']
                      .indexOf(currentStep) > index ? 'w-full' : 'w-0'
                  }`} />
                </div>
              )}
            </div>
          ))}
        </div>
      </div>

      {/* Error Display */}
      {error && (
        <div className="mb-6 p-4 bg-red-500/10 text-red-400 rounded-xl">
          {error}
        </div>
      )}

      {/* Current Step Content */}
      {renderCurrentStep()}
    </div>
  );
}