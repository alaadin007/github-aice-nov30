import React from 'react';
import { Brain, Clock, Award, BookOpen, AlertTriangle } from 'lucide-react';
import { useContentAnalysis } from '../hooks/useContentAnalysis';
import type { ContentMetadata } from '../types/content';

interface ContentAnalyzerProps {
  content: string;
  metadata: ContentMetadata;
  onAnalysisComplete: (result: any) => void;
}

export function ContentAnalyzer({ content, metadata, onAnalysisComplete }: ContentAnalyzerProps) {
  const { analyze, isAnalyzing, result, error } = useContentAnalysis();

  React.useEffect(() => {
    const performAnalysis = async () => {
      try {
        const analysis = await analyze(content, metadata);
        onAnalysisComplete(analysis);
      } catch (err) {
        console.error('Analysis failed:', err);
      }
    };

    performAnalysis();
  }, [content, metadata]);

  if (error) {
    return (
      <div className="bg-red-500/10 rounded-xl p-6 flex items-start gap-3">
        <AlertTriangle className="w-6 h-6 text-red-500 shrink-0" />
        <div>
          <h3 className="text-lg font-medium text-red-500">Analysis Failed</h3>
          <p className="text-red-400 mt-1">{error}</p>
        </div>
      </div>
    );
  }

  if (isAnalyzing) {
    return (
      <div className="glass-effect rounded-xl p-8 text-center">
        <div className="w-16 h-16 rounded-full bg-blue-500/20 flex items-center justify-center mx-auto mb-4">
          <Brain className="w-8 h-8 text-blue-500 animate-pulse" />
        </div>
        <h3 className="text-xl font-bold mb-2">Analyzing Content</h3>
        <p className="text-gray-400">
          Our AI is analyzing your content to determine appropriate KIU points...
        </p>
      </div>
    );
  }

  if (!result) return null;

  return (
    <div className="glass-effect rounded-xl p-6 space-y-6">
      <div className="flex items-center justify-between">
        <h3 className="text-xl font-bold">Analysis Results</h3>
        <div className="flex items-center gap-2">
          <Award className="w-5 h-5 text-yellow-500" />
          <span className="text-lg font-bold">{result.analysis.suggestedKIUPoints} KIU</span>
        </div>
      </div>

      <div className="grid md:grid-cols-3 gap-4">
        <div className="bg-zinc-800/50 rounded-xl p-4">
          <div className="flex items-center gap-2 mb-2">
            <BookOpen className="w-5 h-5 text-blue-500" />
            <span className="font-medium">Difficulty</span>
          </div>
          <span className="text-lg capitalize">{result.analysis.difficulty}</span>
        </div>

        <div className="bg-zinc-800/50 rounded-xl p-4">
          <div className="flex items-center gap-2 mb-2">
            <Clock className="w-5 h-5 text-green-500" />
            <span className="font-medium">Duration</span>
          </div>
          <span className="text-lg">{result.analysis.estimatedDuration} minutes</span>
        </div>

        <div className="bg-zinc-800/50 rounded-xl p-4">
          <div className="flex items-center gap-2 mb-2">
            <Brain className="w-5 h-5 text-purple-500" />
            <span className="font-medium">Confidence</span>
          </div>
          <span className="text-lg">{(result.analysis.confidence * 100).toFixed(1)}%</span>
        </div>
      </div>

      <div>
        <h4 className="font-medium mb-2">Summary</h4>
        <p className="text-gray-300">{result.analysis.summary}</p>
      </div>

      <div>
        <h4 className="font-medium mb-2">Topics Covered</h4>
        <div className="flex flex-wrap gap-2">
          {result.analysis.topics.map((topic, index) => (
            <span
              key={index}
              className="px-3 py-1 rounded-full bg-blue-500/10 text-blue-400 text-sm"
            >
              {topic}
            </span>
          ))}
        </div>
      </div>
    </div>
  );
}