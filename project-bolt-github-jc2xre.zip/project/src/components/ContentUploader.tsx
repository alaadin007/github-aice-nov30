import React, { useState, useRef } from 'react';
import { Upload, AlertCircle, FileText, Youtube, Link as LinkIcon, Plus, X } from 'lucide-react';
import { processContent } from '../services/content';

interface ContentUploaderProps {
  onUpload: () => void;
}

interface ContentInput {
  id: string;
  url: string;
  type: 'youtube' | 'pdf' | 'doc' | 'link';
  status: 'pending' | 'processing' | 'error' | 'success';
  error?: string;
}

export function ContentUploader({ onUpload }: ContentUploaderProps) {
  const [inputs, setInputs] = useState<ContentInput[]>([
    { id: '1', url: '', type: 'youtube', status: 'pending' }
  ]);
  const [isProcessing, setIsProcessing] = useState(false);
  const [isDragging, setIsDragging] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleAddInput = () => {
    setInputs(prev => [
      ...prev,
      { id: Date.now().toString(), url: '', type: 'youtube', status: 'pending' }
    ]);
  };

  const handleRemoveInput = (id: string) => {
    setInputs(prev => prev.filter(input => input.id !== id));
  };

  const handleUrlChange = (id: string, url: string) => {
    setInputs(prev => prev.map(input => 
      input.id === id ? { ...input, url, status: 'pending', error: undefined } : input
    ));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (inputs.every(input => !input.url.trim())) return;

    setIsProcessing(true);

    try {
      // Process all inputs in parallel
      const results = await Promise.allSettled(
        inputs
          .filter(input => input.url.trim())
          .map(async input => {
            try {
              setInputs(prev => prev.map(i => 
                i.id === input.id ? { ...i, status: 'processing' } : i
              ));
              
              await processContent(input.url);
              
              setInputs(prev => prev.map(i => 
                i.id === input.id ? { ...i, status: 'success' } : i
              ));
            } catch (err) {
              const message = err instanceof Error ? err.message : 'Failed to process content';
              setInputs(prev => prev.map(i => 
                i.id === input.id ? { ...i, status: 'error', error: message } : i
              ));
              throw err;
            }
          })
      );

      // If all succeeded, trigger onUpload
      if (results.every(result => result.status === 'fulfilled')) {
        onUpload();
      }
    } finally {
      setIsProcessing(false);
    }
  };

  const handleDragEnter = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(true);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
  };

  const handleDrop = async (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);

    // Handle dropped files
    if (e.dataTransfer.files.length > 0) {
      const files = Array.from(e.dataTransfer.files);
      const newInputs = files.map(file => ({
        id: Date.now().toString() + Math.random(),
        url: URL.createObjectURL(file),
        type: getFileType(file.name),
        status: 'pending' as const
      }));
      setInputs(prev => [...prev, ...newInputs]);
      return;
    }

    // Handle dropped text (URLs)
    const text = e.dataTransfer.getData('text');
    if (text) {
      const urls = text.split('\n').filter(url => url.trim());
      const newInputs = urls.map(url => ({
        id: Date.now().toString() + Math.random(),
        url: url.trim(),
        type: 'youtube',
        status: 'pending' as const
      }));
      setInputs(prev => [...prev, ...newInputs]);
    }
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      const files = Array.from(e.target.files);
      const newInputs = files.map(file => ({
        id: Date.now().toString() + Math.random(),
        url: URL.createObjectURL(file),
        type: getFileType(file.name),
        status: 'pending' as const
      }));
      setInputs(prev => [...prev, ...newInputs]);
    }
  };

  const getFileType = (filename: string): ContentInput['type'] => {
    const ext = filename.toLowerCase().split('.').pop();
    switch (ext) {
      case 'pdf':
        return 'pdf';
      case 'doc':
      case 'docx':
      case 'ppt':
      case 'pptx':
        return 'doc';
      default:
        return 'link';
    }
  };

  return (
    <div className="w-full">
      <div 
        className={`glass-effect rounded-2xl p-6 ${
          isDragging ? 'border-2 border-dashed border-blue-500' : ''
        }`}
        onDragEnter={handleDragEnter}
        onDragLeave={handleDragLeave}
        onDragOver={handleDragOver}
        onDrop={handleDrop}
      >
        <form onSubmit={handleSubmit} className="space-y-4">
          {inputs.map((input, index) => (
            <div key={input.id} className="relative">
              <div className="flex gap-2">
                <div className="relative flex-1">
                  <LinkIcon className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
                  <input
                    type="text"
                    value={input.url}
                    onChange={(e) => handleUrlChange(input.id, e.target.value)}
                    placeholder="Paste a link to any educational content..."
                    className="w-full pl-10 pr-4 py-3 bg-zinc-800 border border-zinc-700 rounded-xl text-white placeholder-gray-400 focus:border-blue-500 focus:outline-none"
                  />
                </div>
                
                {inputs.length > 1 && (
                  <button
                    type="button"
                    onClick={() => handleRemoveInput(input.id)}
                    className="p-3 bg-zinc-800 hover:bg-zinc-700 rounded-xl text-gray-400 hover:text-white transition-colors"
                  >
                    <X className="w-5 h-5" />
                  </button>
                )}
              </div>

              {input.status === 'processing' && (
                <div className="absolute right-16 top-1/2 transform -translate-y-1/2">
                  <div className="w-5 h-5 border-2 border-blue-500/30 border-t-blue-500 rounded-full animate-spin" />
                </div>
              )}

              {input.error && (
                <div className="flex items-center gap-2 text-red-400 text-sm mt-2">
                  <AlertCircle className="w-4 h-4" />
                  {input.error}
                </div>
              )}
            </div>
          ))}

          <div className="flex justify-between items-center">
            <div className="flex gap-2">
              <button
                type="button"
                onClick={handleAddInput}
                className="btn-secondary flex items-center gap-2"
              >
                <Plus className="w-4 h-4" />
                Add Another Source
              </button>

              <button
                type="button"
                onClick={() => fileInputRef.current?.click()}
                className="btn-secondary flex items-center gap-2"
              >
                <Upload className="w-4 h-4" />
                Upload Files
              </button>
              <input
                ref={fileInputRef}
                type="file"
                multiple
                accept=".pdf,.doc,.docx,.ppt,.pptx"
                onChange={handleFileSelect}
                className="hidden"
              />
            </div>

            <button
              type="submit"
              disabled={isProcessing || inputs.every(input => !input.url.trim())}
              className="btn-primary flex items-center gap-2"
            >
              {isProcessing ? (
                <span className="inline-block w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
              ) : (
                'Process Content'
              )}
            </button>
          </div>
        </form>

        {/* Drag & Drop Zone */}
        <div className="mt-6 border-2 border-dashed border-zinc-700 rounded-xl p-8 text-center hover:border-blue-500 transition-colors">
          <Upload className="w-8 h-8 text-blue-500 mx-auto mb-3" />
          <p className="text-gray-400 mb-1">
            Drag and drop files or paste a link
          </p>
          <p className="text-sm text-gray-500">
            Supported: YouTube videos, PDF, Word, PowerPoint
          </p>
        </div>

        {/* File Type Icons */}
        <div className="flex justify-center gap-8 mt-6">
          <div className="text-center">
            <div className="w-10 h-10 rounded-lg bg-blue-500/20 flex items-center justify-center mb-2">
              <Youtube className="w-5 h-5 text-blue-500" />
            </div>
            <span className="text-xs text-gray-400">YouTube</span>
          </div>
          <div className="text-center">
            <div className="w-10 h-10 rounded-lg bg-purple-500/20 flex items-center justify-center mb-2">
              <FileText className="w-5 h-5 text-purple-500" />
            </div>
            <span className="text-xs text-gray-400">PDF</span>
          </div>
          <div className="text-center">
            <div className="w-10 h-10 rounded-lg bg-green-500/20 flex items-center justify-center mb-2">
              <Upload className="w-5 h-5 text-green-500" />
            </div>
            <span className="text-xs text-gray-400">Word/PPT</span>
          </div>
        </div>
      </div>
    </div>
  );
}