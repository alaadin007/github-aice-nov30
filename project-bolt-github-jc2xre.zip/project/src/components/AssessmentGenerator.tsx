import React, { useState } from 'react';
import { Brain, AlertTriangle, CheckCircle, HelpCircle } from 'lucide-react';
import { generateQuestions, calculateAssessmentScore } from '../utils/assessment';
import type { AssessmentQuestion } from '../types/kiu';

interface AssessmentGeneratorProps {
  content: string;
  onComplete: (score: number) => void;
}

export function AssessmentGenerator({ content, onComplete }: AssessmentGeneratorProps) {
  const [questions, setQuestions] = useState<AssessmentQuestion[]>([]);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [answers, setAnswers] = useState<Record<string, string>>({});
  const [isGenerating, setIsGenerating] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [showExplanation, setShowExplanation] = useState(false);

  React.useEffect(() => {
    const generateAssessment = async () => {
      try {
        setIsGenerating(true);
        setError(null);
        const generatedQuestions = await generateQuestions(content);
        setQuestions(generatedQuestions);
      } catch (err) {
        setError(err instanceof Error ? err.message : 'Failed to generate questions');
      } finally {
        setIsGenerating(false);
      }
    };

    generateAssessment();
  }, [content]);

  const handleAnswer = (questionId: string, answerId: string) => {
    setAnswers(prev => ({ ...prev, [questionId]: answerId }));
    setShowExplanation(true);
  };

  const handleNext = () => {
    if (currentIndex < questions.length - 1) {
      setCurrentIndex(prev => prev + 1);
      setShowExplanation(false);
    } else {
      const score = calculateAssessmentScore(questions, answers);
      onComplete(score);
    }
  };

  if (error) {
    return (
      <div className="bg-red-500/10 rounded-xl p-6 flex items-start gap-3">
        <AlertTriangle className="w-6 h-6 text-red-500 shrink-0" />
        <div>
          <h3 className="text-lg font-medium text-red-500">Generation Failed</h3>
          <p className="text-red-400 mt-1">{error}</p>
        </div>
      </div>
    );
  }

  if (isGenerating) {
    return (
      <div className="glass-effect rounded-xl p-8 text-center">
        <div className="w-16 h-16 rounded-full bg-blue-500/20 flex items-center justify-center mx-auto mb-4">
          <Brain className="w-8 h-8 text-blue-500 animate-pulse" />
        </div>
        <h3 className="text-xl font-bold mb-2">Generating Assessment</h3>
        <p className="text-gray-400">
          Creating questions to test your understanding...
        </p>
      </div>
    );
  }

  if (questions.length === 0) return null;

  const currentQuestion = questions[currentIndex];
  const userAnswer = answers[currentQuestion.id];
  const isCorrect = userAnswer === currentQuestion.correctAnswer;

  return (
    <div className="glass-effect rounded-xl p-6 space-y-6">
      <div className="flex items-center justify-between">
        <h3 className="text-xl font-bold">Question {currentIndex + 1}/{questions.length}</h3>
        <span className={`px-3 py-1 rounded-full text-sm ${
          currentQuestion.difficulty === 'beginner' ? 'bg-green-500/20 text-green-500' :
          currentQuestion.difficulty === 'intermediate' ? 'bg-yellow-500/20 text-yellow-500' :
          'bg-red-500/20 text-red-500'
        }`}>
          {currentQuestion.difficulty}
        </span>
      </div>

      <p className="text-lg">{currentQuestion.text}</p>

      <div className="space-y-3">
        {currentQuestion.options.map((option) => (
          <button
            key={option.id}
            onClick={() => handleAnswer(currentQuestion.id, option.id)}
            disabled={userAnswer !== undefined}
            className={`w-full p-4 rounded-xl text-left transition-all ${
              userAnswer === option.id
                ? isCorrect
                  ? 'bg-green-500/20 text-green-500'
                  : 'bg-red-500/20 text-red-500'
                : userAnswer && option.id === currentQuestion.correctAnswer
                ? 'bg-green-500/20 text-green-500'
                : 'bg-zinc-800 text-gray-300 hover:bg-zinc-700'
            }`}
          >
            <div className="flex items-center gap-3">
              <span className={`w-8 h-8 rounded-full border-2 flex items-center justify-center shrink-0 ${
                userAnswer === option.id
                  ? isCorrect
                    ? 'border-green-500'
                    : 'border-red-500'
                  : 'border-gray-400'
              }`}>
                {option.id}
              </span>
              <span>{option.text}</span>
              {userAnswer === option.id && (
                isCorrect
                  ? <CheckCircle className="w-5 h-5 text-green-500 ml-auto" />
                  : <AlertTriangle className="w-5 h-5 text-red-500 ml-auto" />
              )}
            </div>
          </button>
        ))}
      </div>

      {showExplanation && currentQuestion.explanation && (
        <div className="bg-blue-500/10 rounded-xl p-4 flex items-start gap-3">
          <HelpCircle className="w-5 h-5 text-blue-500 shrink-0 mt-0.5" />
          <div>
            <h4 className="font-medium text-blue-500 mb-1">Explanation</h4>
            <p className="text-sm text-blue-400">{currentQuestion.explanation}</p>
          </div>
        </div>
      )}

      {userAnswer && (
        <div className="flex justify-end">
          <button
            onClick={handleNext}
            className="btn-primary"
          >
            {currentIndex < questions.length - 1 ? 'Next Question' : 'Complete Assessment'}
          </button>
        </div>
      )}
    </div>
  );
}