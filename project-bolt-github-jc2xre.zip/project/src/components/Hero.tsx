import React from 'react';
import { Star, Brain, Award, Users, TrendingUp } from 'lucide-react';
import { ContentUploader } from './ContentUploader';

interface HeroProps {
  onTryDemo: () => void;
}

export function Hero({ onTryDemo }: HeroProps) {
  return (
    <div className="mb-20">
      {/* Main Hero */}
      <div className="text-center mb-8 pt-8">
        <h2 className="text-6xl font-bold mb-6">
          <span className="text-white">Learn</span>,{' '}
          <span className="text-white">Share</span>,{' '}
          <span className="text-gray-500">Earn Credits</span>
          <Star className="inline-block w-8 h-8 ml-2 text-blue-600" />
        </h2>
        <h3 className="text-2xl mb-4">
          Turn Your <span className="font-semibold">Content</span> into{' '}
          <span className="font-semibold">Professional Credits</span>
        </h3>
        <p className="text-gray-400 text-lg mb-12">
          Instant CPD, CME, CE & More - No Login Required
        </p>

        {/* Demo Section */}
        <div className="mb-12">
          <ContentUploader onUpload={onTryDemo} />
        </div>

        {/* Features Grid */}
        <div className="grid md:grid-cols-3 gap-6 max-w-6xl mx-auto">
          {/* KIU Feature */}
          <div className="glass-effect rounded-xl p-6 hover:bg-zinc-800/50 transition-duration-300">
            <div className="w-12 h-12 rounded-xl bg-blue-500/20 flex items-center justify-center mb-4">
              <Award className="w-6 h-6 text-blue-500" />
            </div>
            <h3 className="text-xl font-bold text-white mb-3">Instant Recognition</h3>
            <p className="text-gray-400 leading-relaxed">
              Share any educational content and get instant professional development credits recognized worldwide.
            </p>
          </div>

          {/* AI Analysis */}
          <div className="glass-effect rounded-xl p-6 hover:bg-zinc-800/50 transition-duration-300">
            <div className="w-12 h-12 rounded-xl bg-purple-500/20 flex items-center justify-center mb-4">
              <Brain className="w-6 h-6 text-purple-500" />
            </div>
            <h3 className="text-xl font-bold text-white mb-3">AI-Powered Analysis</h3>
            <p className="text-gray-400 leading-relaxed">
              Our AI analyzes your content depth and generates relevant assessments in seconds.
            </p>
          </div>

          {/* Certificates */}
          <div className="glass-effect rounded-xl p-6 hover:bg-zinc-800/50 transition-duration-300">
            <div className="w-12 h-12 rounded-xl bg-green-500/20 flex items-center justify-center mb-4">
              <Award className="w-6 h-6 text-green-500" />
            </div>
            <h3 className="text-xl font-bold text-white mb-3">Instant Certificates</h3>
            <p className="text-gray-400 leading-relaxed">
              Get verified certificates immediately after completing the quick assessment.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}