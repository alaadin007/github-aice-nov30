import axios from 'axios';
import { config } from '../config';

interface VideoInfo {
  title?: string;
  author?: string;
}

interface YouTubeResponse {
  captions: string;
  videoInfo?: VideoInfo;
}

export async function extractSubtitles(videoId: string): Promise<YouTubeResponse> {
  try {
    // First try to get video info
    const videoInfo = await getVideoInfo(videoId);

    // Then get captions
    const response = await axios.get<YouTubeResponse>(
      `${config.apiUrl}/api/youtube/captions/${videoId}`,
      { 
        validateStatus: status => status < 500,
        timeout: 10000 // 10 second timeout
      }
    );

    if (response.status !== 200) {
      throw new Error(response.data.error || 'Failed to extract video subtitles');
    }

    return {
      captions: response.data.captions,
      videoInfo
    };
  } catch (error) {
    console.error('Error extracting subtitles:', error);
    throw new Error('Failed to extract video subtitles. Please try again.');
  }
}

async function getVideoInfo(videoId: string): Promise<VideoInfo | undefined> {
  try {
    const response = await axios.get(
      `https://www.youtube.com/oembed?url=http://www.youtube.com/watch?v=${videoId}&format=json`,
      { timeout: 5000 }
    );
    return {
      title: response.data.title,
      author: response.data.author_name
    };
  } catch (error) {
    console.error('Error fetching video info:', error);
    return undefined;
  }
}

export function extractVideoId(url: string): string | null {
  try {
    const urlObj = new URL(url);
    const searchParams = new URLSearchParams(urlObj.search);
    
    if (urlObj.hostname.includes('youtu.be')) {
      return urlObj.pathname.slice(1);
    }
    
    return searchParams.get('v');
  } catch {
    return null;
  }
}

export function validateYouTubeUrl(url: string): boolean {
  try {
    const urlObj = new URL(url);
    return urlObj.hostname.includes('youtube.com') || urlObj.hostname.includes('youtu.be');
  } catch {
    return false;
  }
}