import { config } from '../config';
import type { ContentMetadata } from '../types/content';
import { extractSubtitles, validateYouTubeUrl, extractVideoId } from './youtube';

interface ProcessedContent {
  content: string;
  metadata: ContentMetadata;
}

export async function processContent(input: string): Promise<ProcessedContent> {
  try {
    // Check if input is a YouTube URL
    if (validateYouTubeUrl(input)) {
      const videoId = extractVideoId(input);
      if (!videoId) {
        throw new Error('Invalid YouTube URL');
      }
      
      const { captions, videoInfo } = await extractSubtitles(videoId);
      
      if (!captions) {
        throw new Error('No captions available for this video');
      }

      return {
        content: captions,
        metadata: {
          title: videoInfo?.title || 'YouTube Video',
          type: 'youtube',
          source: input,
          timestamp: new Date().toISOString()
        }
      };
    }

    // Check if input is a PDF URL
    if (input.toLowerCase().endsWith('.pdf')) {
      // TODO: Implement PDF processing
      throw new Error('PDF processing coming soon');
    }

    // Check if input is a Word/PPT URL
    if (input.toLowerCase().match(/\.(doc|docx|ppt|pptx)$/)) {
      // TODO: Implement Office document processing
      throw new Error('Office document processing coming soon');
    }

    // For now, treat all other input as plain text
    return {
      content: input,
      metadata: {
        title: 'Text Content',
        type: 'text',
        source: 'direct',
        timestamp: new Date().toISOString()
      }
    };
  } catch (error) {
    console.error('Error processing content:', error);
    if (error instanceof Error) {
      throw error;
    }
    throw new Error('Failed to process content');
  }
}