import OpenAI from 'openai';
import { config } from '../config';
import type { ContentAnalysis, ContentMetadata } from '../types/content';

const openai = new OpenAI({
  apiKey: config.openaiApiKey,
  organization: config.openaiOrgId,
  dangerouslyAllowBrowser: true // Enable browser usage
});

const SYSTEM_PROMPT = `You are an expert AI assistant specializing in analyzing educational content for the AiCE (AI Continuing Education) platform.
Your task is to analyze content and determine:
1. Key topics covered
2. Content difficulty level
3. Estimated time to complete
4. Suggested KIU (Knowledge Impact Units) points
5. A comprehensive yet concise summary

Focus on medical and aesthetic education content. Be precise in your analysis.`;

export async function analyzeContent(content: string, metadata: ContentMetadata): Promise<ContentAnalysis> {
  try {
    const completion = await openai.chat.completions.create({
      model: "gpt-4-turbo-preview",
      messages: [
        { role: "system", content: SYSTEM_PROMPT },
        { 
          role: "user", 
          content: `Please analyze this ${metadata.type} content:\n\nTitle: ${metadata.title}\n\nContent:\n${content}`
        }
      ],
      temperature: 0.7,
      max_tokens: 1000,
      response_format: { type: "json_object" }
    });

    const result = JSON.parse(completion.choices[0].message.content || '{}');

    return {
      metadata,
      analysis: {
        summary: result.summary,
        topics: result.topics,
        difficulty: result.difficulty,
        estimatedDuration: result.estimated_duration,
        suggestedKIUPoints: result.suggested_kiu_points,
        confidence: result.confidence
      },
      rawContent: content
    };
  } catch (error) {
    console.error('Error analyzing content:', error);
    throw new Error('Failed to analyze content');
  }
}