import axios from 'axios';
import { config } from '../config';

const api = axios.create({
  baseURL: config.apiUrl,
  headers: {
    'Content-Type': 'application/json'
  }
});

// Add auth token to requests if available
api.interceptors.request.use((config) => {
  const token = localStorage.getItem('token');
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

export const auth = {
  login: async (email: string, password: string) => {
    const response = await api.post('/auth/login', { email, password });
    return response.data;
  },
  register: async (data: { email: string; password: string; name: string; organization?: string }) => {
    const response = await api.post('/auth/register', data);
    return response.data;
  }
};

export const certificates = {
  create: async (data: {
    title: string;
    description: string;
    kiuPoints: number;
    type: 'youtube' | 'pdf' | 'text';
    source: string;
  }) => {
    const response = await api.post('/certificates', data);
    return response.data;
  },
  getUserCertificates: async (userId: string) => {
    const response = await api.get(`/certificates/user/${userId}`);
    return response.data;
  },
  verify: async (id: string) => {
    const response = await api.get(`/certificates/verify/${id}`);
    return response.data;
  }
};

export const youtube = {
  extractSubtitles: async (videoId: string) => {
    const response = await api.get(`/youtube/captions/${videoId}`);
    return response.data;
  }
};

export default api;