export const config = {
  apiUrl: import.meta.env.VITE_API_URL || 'http://localhost:3000',
  apiKey: import.meta.env.VITE_API_KEY,
  aestheticProjectId: import.meta.env.VITE_AESTHETIC_PROJECT_ID || 'aice-aesthetic-intelligence-001',
  openaiApiKey: import.meta.env.VITE_OPENAI_API_KEY || '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',
  openaiOrgId: import.meta.env.VITE_OPENAI_ORG_ID || 'org-H4VReE24ZreRb4edYQ2HOkMn',
  searchApiKey: import.meta.env.VITE_SEARCH_API_KEY || 'eSkBsbUJAYdiHqPdDk13BGeK',
  youtubeApiEndpoint: 'https://www.searchapi.io/api/v1/search'
};