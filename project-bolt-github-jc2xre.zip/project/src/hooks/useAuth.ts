import { useState, useEffect } from 'react';
import { auth } from '../services/api';

interface User {
  id: string;
  email: string;
  name: string;
  organization?: string;
  memberNumber: string;
  role: string;
}

interface AuthState {
  user: User | null;
  token: string | null;
}

export function useAuth() {
  const [state, setState] = useState<AuthState>(() => {
    const token = localStorage.getItem('token');
    const user = localStorage.getItem('user');
    return {
      token,
      user: user ? JSON.parse(user) : null
    };
  });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (state.token) {
      localStorage.setItem('token', state.token);
    } else {
      localStorage.removeItem('token');
    }

    if (state.user) {
      localStorage.setItem('user', JSON.stringify(state.user));
    } else {
      localStorage.removeItem('user');
    }
  }, [state]);

  const login = async (email: string, password: string) => {
    try {
      setLoading(true);
      setError(null);
      const { token, user } = await auth.login(email, password);
      setState({ token, user });
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Login failed');
      throw err;
    } finally {
      setLoading(false);
    }
  };

  const register = async (data: { email: string; password: string; name: string; organization?: string }) => {
    try {
      setLoading(true);
      setError(null);
      const { token, user } = await auth.register(data);
      setState({ token, user });
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Registration failed');
      throw err;
    } finally {
      setLoading(false);
    }
  };

  const logout = () => {
    setState({ token: null, user: null });
  };

  return {
    user: state.user,
    token: state.token,
    loading,
    error,
    login,
    register,
    logout
  };
}