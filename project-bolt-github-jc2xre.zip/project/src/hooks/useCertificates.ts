import { useState } from 'react';
import { certificates } from '../services/api';
import type { ContentAnalysis } from '../types/content';

export function useCertificates() {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const generateCertificate = async (analysis: ContentAnalysis) => {
    try {
      setLoading(true);
      setError(null);

      const certificate = await certificates.create({
        title: analysis.metadata.title,
        description: analysis.analysis.summary,
        kiuPoints: analysis.analysis.suggestedKIUPoints,
        type: analysis.metadata.type,
        source: analysis.metadata.source
      });

      return certificate;
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to generate certificate');
      throw err;
    } finally {
      setLoading(false);
    }
  };

  const getUserCertificates = async (userId: string) => {
    try {
      setLoading(true);
      setError(null);
      return await certificates.getUserCertificates(userId);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to fetch certificates');
      throw err;
    } finally {
      setLoading(false);
    }
  };

  return {
    generateCertificate,
    getUserCertificates,
    loading,
    error
  };
}