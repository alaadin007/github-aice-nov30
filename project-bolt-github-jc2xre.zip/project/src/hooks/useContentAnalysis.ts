import { useState } from 'react';
import { analyzeContent } from '../services/openai';
import type { ContentAnalysis, ContentMetadata } from '../types/content';

export function useContentAnalysis() {
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [result, setResult] = useState<ContentAnalysis | null>(null);
  const [error, setError] = useState<string | null>(null);

  const analyze = async (content: string, metadata: ContentMetadata) => {
    try {
      setIsAnalyzing(true);
      setError(null);
      const analysis = await analyzeContent(content, metadata);
      setResult(analysis);
      return analysis;
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Failed to analyze content';
      setError(message);
      throw err;
    } finally {
      setIsAnalyzing(false);
    }
  };

  return {
    analyze,
    isAnalyzing,
    result,
    error
  };
}