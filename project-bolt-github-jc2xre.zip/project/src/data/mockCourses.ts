export const MOCK_COURSES = [
  {
    id: 1,
    title: "Masseter Botox Treatment Update",
    date: "2024-02-20",
    sources: 2,
    points: 1,
    icon: "💉",
    summary: "Advanced injection techniques and patient management strategies for optimal facial aesthetics and bruxism treatment outcomes.",
    status: "completed" as const,
    score: 92
  },
  {
    id: 2,
    title: "Advanced Dermal Fillers",
    date: "2024-02-18",
    sources: 3,
    points: 2,
    icon: "🔬",
    summary: "Comprehensive guide to advanced dermal filler techniques, including facial anatomy and injection patterns.",
    status: "in-progress" as const
  },
  {
    id: 3,
    title: "Patient Communication Workshop",
    date: "2024-02-15",
    sources: 1,
    points: 1,
    icon: "👥",
    summary: "Effective strategies for patient consultation, expectation management, and building long-term relationships.",
    status: "completed" as const,
    score: 88
  }
];