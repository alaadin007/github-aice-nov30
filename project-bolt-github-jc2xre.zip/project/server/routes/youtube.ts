import { Router } from 'express';
import { getSubtitles } from 'youtube-captions-scraper';
import axios from 'axios';

const router = Router();

async function getVideoInfo(videoId: string) {
  try {
    const response = await axios.get(
      `https://www.youtube.com/oembed?url=http://www.youtube.com/watch?v=${videoId}&format=json`,
      { timeout: 5000 }
    );
    return {
      title: response.data.title,
      author: response.data.author_name
    };
  } catch (error) {
    console.error('Error fetching video info:', error);
    return null;
  }
}

router.get('/captions/:videoId', async (req, res) => {
  try {
    const { videoId } = req.params;
    
    // Get both captions and video info in parallel
    const [captionsData, videoInfo] = await Promise.all([
      getSubtitles({
        videoID: videoId,
        lang: 'en'
      }),
      getVideoInfo(videoId)
    ]);

    // Format captions into readable text
    const text = captionsData
      .map(caption => caption.text)
      .join(' ')
      .replace(/\s+/g, ' ')
      .trim();

    res.json({
      captions: text,
      videoInfo
    });
  } catch (error) {
    console.error('Error extracting captions:', error);
    res.status(500).json({ 
      error: 'Failed to extract video subtitles',
      details: error instanceof Error ? error.message : 'Unknown error'
    });
  }
});

export const youtubeRouter = router;