import { Router } from 'express';
import { z } from 'zod';
import QRCode from 'qrcode';
import prisma from '../db';
import { authMiddleware } from '../middleware/auth';
import { config } from '../config';

const router = Router();

const CreateCertificateSchema = z.object({
  title: z.string(),
  description: z.string(),
  kiuPoints: z.number(),
  type: z.enum(['youtube', 'pdf', 'text']),
  source: z.string()
});

router.post('/', authMiddleware, async (req, res) => {
  try {
    const data = CreateCertificateSchema.parse(req.body);
    const userId = (req as any).user.id;

    // Generate verification QR code
    const verificationId = `cert-${Math.random().toString(36).substr(2, 9)}`;
    const verificationUrl = `${config.appUrl}/verify/${verificationId}`;
    const qrCode = await QRCode.toDataURL(verificationUrl);

    const certificate = await prisma.certificate.create({
      data: {
        ...data,
        userId,
        verificationQr: qrCode
      }
    });

    // Update user's total points
    await prisma.user.update({
      where: { id: userId },
      data: {
        totalPoints: {
          increment: data.kiuPoints
        }
      }
    });

    res.json(certificate);
  } catch (error) {
    console.error('Certificate creation error:', error);
    res.status(400).json({ 
      error: error instanceof z.ZodError 
        ? error.errors[0].message 
        : 'Failed to create certificate' 
    });
  }
});

router.get('/user/:userId', authMiddleware, async (req, res) => {
  try {
    const { userId } = req.params;
    const certificates = await prisma.certificate.findMany({
      where: { userId },
      orderBy: { createdAt: 'desc' }
    });
    res.json(certificates);
  } catch (error) {
    console.error('Error fetching certificates:', error);
    res.status(500).json({ error: 'Failed to fetch certificates' });
  }
});

router.get('/verify/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const certificate = await prisma.certificate.findUnique({
      where: { id },
      include: {
        user: {
          select: {
            name: true,
            organization: true,
            memberNumber: true
          }
        }
      }
    });

    if (!certificate) {
      return res.status(404).json({ error: 'Certificate not found' });
    }

    res.json(certificate);
  } catch (error) {
    console.error('Certificate verification error:', error);
    res.status(500).json({ error: 'Failed to verify certificate' });
  }
});

export const certificatesRouter = router;